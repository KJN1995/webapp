import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { yahooFinance } from '@/lib/yahoo-finance'

const newsSchema = z.object({
  symbol: z.string().min(1).max(10),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol')
    
    if (!symbol) {
      return NextResponse.json({ error: 'Symbol parameter required' }, { status: 400 })
    }

    const validation = newsSchema.safeParse({ symbol })
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid symbol parameter' }, { status: 400 })
    }

    const symbolUpper = validation.data.symbol.toUpperCase()

    try {
      const articles = await yahooFinance.getNews(symbolUpper)
      
      // Calculate basic sentiment from news titles
      const sentiment = calculateBasicSentiment(articles)
      const summary = generateNewsSummary(articles)

      const result = {
        articles,
        sentiment: sentiment.score,
        sentiment_label: sentiment.label,
        summary,
        _source: 'yahoo_finance'
      }

      return NextResponse.json(result)
    } catch (error) {
      console.error('Yahoo Finance news error:', error)
      return NextResponse.json({ error: 'Failed to fetch news data' }, { status: 500 })
    }
  } catch (error) {
    console.error('News API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

function calculateBasicSentiment(articles: any[]): { score: number; label: string } {
  if (!articles.length) return { score: 0.5, label: 'Neutral' }

  const positiveWords = ['up', 'rise', 'gain', 'profit', 'growth', 'strong', 'beat', 'positive', 'bull', 'upgrade']
  const negativeWords = ['down', 'fall', 'loss', 'decline', 'weak', 'miss', 'negative', 'bear', 'downgrade', 'cut']

  let totalScore = 0
  let scoredArticles = 0

  for (const article of articles.slice(0, 10)) { // Analyze first 10 articles
    const text = `${article.title} ${article.summary || ''}`.toLowerCase()
    
    let articleScore = 0.5 // Neutral baseline
    
    const positiveCount = positiveWords.reduce((count, word) => 
      count + (text.split(word).length - 1), 0)
    const negativeCount = negativeWords.reduce((count, word) => 
      count + (text.split(word).length - 1), 0)
    
    if (positiveCount > negativeCount) {
      articleScore = 0.5 + Math.min(0.4, positiveCount * 0.1)
    } else if (negativeCount > positiveCount) {
      articleScore = 0.5 - Math.min(0.4, negativeCount * 0.1)
    }
    
    totalScore += articleScore
    scoredArticles++
  }

  const avgScore = scoredArticles > 0 ? totalScore / scoredArticles : 0.5
  
  let label = 'Neutral'
  if (avgScore > 0.6) label = 'Positive'
  else if (avgScore < 0.4) label = 'Negative'

  return { score: Math.round(avgScore * 100) / 100, label }
}

function generateNewsSummary(articles: any[]): string {
  if (!articles.length) return 'No recent news available'
  
  const recentCount = articles.length
  const sources = [...new Set(articles.map(a => a.source))].slice(0, 3)
  
  return `${recentCount} recent articles from ${sources.join(', ')}${sources.length > 3 ? ' and others' : ''}`
}