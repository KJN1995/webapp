import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { yahooFinance } from '@/lib/yahoo-finance'

const searchSchema = z.object({
  q: z.string().min(1).max(20),
})

interface SearchResult {
  symbol: string
  name: string
  exchange: string
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get('q')
    
    if (!query) {
      return NextResponse.json({ error: 'Query parameter required' }, { status: 400 })
    }

    const validation = searchSchema.safeParse({ q: query })
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid query parameter' }, { status: 400 })
    }

    try {
      // Use Yahoo Finance search
      const yahooResults = await yahooFinance.searchSymbols(validation.data.q)
      
      const results: SearchResult[] = yahooResults.map(result => ({
        symbol: result.symbol,
        name: result.name,
        exchange: result.exchDisp || result.exch
      })).slice(0, 15) // Limit to 15 results

      return NextResponse.json({ results })
    } catch (error) {
      console.error('Yahoo Finance search error:', error)
      
      // Fallback to basic search if Yahoo fails
      const fallbackResults: SearchResult[] = []
      const commonStocks = [
        { symbol: 'AAPL', name: 'Apple Inc.', exchange: 'NASDAQ' },
        { symbol: 'MSFT', name: 'Microsoft Corporation', exchange: 'NASDAQ' },
        { symbol: 'GOOGL', name: 'Alphabet Inc.', exchange: 'NASDAQ' },
        { symbol: 'AMZN', name: 'Amazon.com Inc.', exchange: 'NASDAQ' },
        { symbol: 'TSLA', name: 'Tesla Inc.', exchange: 'NASDAQ' },
        { symbol: 'META', name: 'Meta Platforms Inc.', exchange: 'NASDAQ' },
        { symbol: 'NVDA', name: 'NVIDIA Corporation', exchange: 'NASDAQ' },
        { symbol: 'NFLX', name: 'Netflix Inc.', exchange: 'NASDAQ' }
      ]
      
      const searchQuery = validation.data.q.toUpperCase()
      const filtered = commonStocks.filter(stock => 
        stock.symbol.includes(searchQuery) ||
        stock.name.toLowerCase().includes(validation.data.q.toLowerCase())
      )
      
      return NextResponse.json({ results: filtered })
    }
  } catch (error) {
    console.error('Search API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}