import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { yahooFinance } from '@/lib/yahoo-finance'

const quoteSchema = z.object({
  symbol: z.string().min(1).max(10),
})

interface QuoteData {
  price: number | null
  change: number | null
  changePct: number | null
  marketCap: number | null
  pe: number | null
  range52w: {
    low: number | null
    high: number | null
  }
  lastUpdated: string
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol')
    
    if (!symbol) {
      return NextResponse.json({ error: 'Symbol parameter required' }, { status: 400 })
    }

    const validation = quoteSchema.safeParse({ symbol })
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid symbol parameter' }, { status: 400 })
    }

    const symbolUpper = validation.data.symbol.toUpperCase()

    try {
      const quote = await yahooFinance.getQuote(symbolUpper)
      
      if (!quote) {
        return NextResponse.json({ error: 'Stock not found' }, { status: 404 })
      }

      const quoteData: QuoteData = {
        price: quote.price,
        change: quote.change,
        changePct: quote.changePercent,
        marketCap: quote.marketCap,
        pe: quote.pe,
        range52w: {
          low: quote.fiftyTwoWeekLow,
          high: quote.fiftyTwoWeekHigh,
        },
        lastUpdated: new Date().toISOString(),
      }

      return NextResponse.json(quoteData)
    } catch (error) {
      console.error('Yahoo Finance error:', error)
      return NextResponse.json({ error: 'Failed to fetch stock data' }, { status: 500 })
    }
  } catch (error) {
    console.error('Quote API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}