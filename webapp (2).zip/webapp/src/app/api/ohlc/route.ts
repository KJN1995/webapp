import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { yahooFinance } from '@/lib/yahoo-finance'

const ohlcSchema = z.object({
  symbol: z.string().min(1).max(10),
  range: z.enum(['1D', '1W', '1M', '6M', '1Y', '5Y']).default('1Y'),
  interval: z.enum(['1D', '1W', '1M']).default('1D'),
})

interface CandleData {
  t: number // timestamp
  o: number // open
  h: number // high
  l: number // low
  c: number // close
  v: number // volume
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol')
    const range = searchParams.get('range') || '1Y'
    const interval = searchParams.get('interval') || '1D'
    
    if (!symbol) {
      return NextResponse.json({ error: 'Symbol parameter required' }, { status: 400 })
    }

    const validation = ohlcSchema.safeParse({ symbol, range, interval })
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid parameters' }, { status: 400 })
    }

    const { symbol: validSymbol, range: validRange, interval: validInterval } = validation.data

    try {
      // Map our range format to Yahoo's format
      const yahooRange = validRange.toLowerCase()
      const yahooInterval = validInterval.toLowerCase()

      const historicalData = await yahooFinance.getHistoricalData(validSymbol.toUpperCase(), yahooRange, yahooInterval)
      
      if (!historicalData) {
        return NextResponse.json({ error: 'No historical data found' }, { status: 404 })
      }

      // Transform to our expected format
      const candles: CandleData[] = []
      for (let i = 0; i < historicalData.timestamp.length; i++) {
        if (
          historicalData.open[i] !== null &&
          historicalData.high[i] !== null &&
          historicalData.low[i] !== null &&
          historicalData.close[i] !== null &&
          historicalData.volume[i] !== null
        ) {
          candles.push({
            t: historicalData.timestamp[i],
            o: historicalData.open[i],
            h: historicalData.high[i],
            l: historicalData.low[i],
            c: historicalData.close[i],
            v: historicalData.volume[i],
          })
        }
      }

      return NextResponse.json({ candles })
    } catch (error) {
      console.error('Yahoo Finance OHLC error:', error)
      return NextResponse.json({ error: 'Failed to fetch OHLC data' }, { status: 500 })
    }
  } catch (error) {
    console.error('OHLC API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}