import { NextRequest, NextResponse } from 'next/server'
import { z } from 'zod'
import { yahooFinance } from '@/lib/yahoo-finance'

const fundamentalsSchema = z.object({
  symbol: z.string().min(1).max(10),
})

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get('symbol')
    
    if (!symbol) {
      return NextResponse.json({ error: 'Symbol parameter required' }, { status: 400 })
    }

    const validation = fundamentalsSchema.safeParse({ symbol })
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid symbol parameter' }, { status: 400 })
    }

    const symbolUpper = validation.data.symbol.toUpperCase()

    try {
      const fundamentals = await yahooFinance.getFundamentals(symbolUpper)
      
      if (!fundamentals) {
        return NextResponse.json({ error: 'Fundamentals not found' }, { status: 404 })
      }

      // Calculate basic scoring based on fundamentals
      const scoring = calculateBasicScore(fundamentals)
      const risk = calculateBasicRisk(fundamentals)

      const result = {
        fundamentals,
        scoring,
        risk,
        symbol: symbolUpper
      }

      return NextResponse.json(result)
    } catch (error) {
      console.error('Yahoo Finance fundamentals error:', error)
      return NextResponse.json({ error: 'Failed to fetch fundamentals data' }, { status: 500 })
    }
  } catch (error) {
    console.error('Fundamentals API error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

function calculateBasicScore(fundamentals: any): any {
  let score = 50 // Base score
  
  // PE ratio scoring
  if (fundamentals.pe) {
    if (fundamentals.pe < 15) score += 10
    else if (fundamentals.pe < 25) score += 5
    else if (fundamentals.pe > 40) score -= 10
  }
  
  // ROE scoring
  if (fundamentals.roe) {
    if (fundamentals.roe > 0.15) score += 15
    else if (fundamentals.roe > 0.10) score += 10
    else if (fundamentals.roe < 0.05) score -= 10
  }
  
  // Debt scoring
  if (fundamentals.debt_to_equity) {
    if (fundamentals.debt_to_equity < 0.3) score += 10
    else if (fundamentals.debt_to_equity > 1.0) score -= 10
  }
  
  // Growth scoring
  if (fundamentals.revenue_growth && fundamentals.revenue_growth > 0.1) score += 10
  if (fundamentals.earnings_growth && fundamentals.earnings_growth > 0.1) score += 10

  score = Math.max(0, Math.min(100, score))
  
  let recommendation = 'HOLD'
  if (score >= 75) recommendation = 'STRONG BUY'
  else if (score >= 60) recommendation = 'BUY'
  else if (score <= 25) recommendation = 'SELL'
  else if (score <= 40) recommendation = 'WEAK HOLD'

  return {
    combined_score: score,
    recommendation,
    _methodology: 'basic_yahoo_scoring'
  }
}

function calculateBasicRisk(fundamentals: any): any {
  const risks = []
  let riskLevel = 'MEDIUM'
  
  if (fundamentals.beta && fundamentals.beta > 1.5) {
    risks.push('High volatility (Beta > 1.5)')
    riskLevel = 'HIGH'
  }
  
  if (fundamentals.debt_to_equity && fundamentals.debt_to_equity > 1.0) {
    risks.push('High debt levels')
    if (riskLevel === 'MEDIUM') riskLevel = 'HIGH'
  }
  
  if (fundamentals.pe && fundamentals.pe > 50) {
    risks.push('Very high valuation')
  }
  
  if (fundamentals.current_ratio && fundamentals.current_ratio < 1.0) {
    risks.push('Poor liquidity')
  }

  return {
    risk_level: riskLevel,
    risk_factors: risks,
    risk_summary: risks.length > 0 ? risks.join('; ') : 'No major risk factors identified',
    _methodology: 'basic_yahoo_risk'
  }
}