import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const favoriteSchema = z.object({
  symbol: z.string().min(1).max(10),
})

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const favorites = await prisma.favorite.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ favorites })
  } catch (error) {
    console.error('Get favorites error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validation = favoriteSchema.safeParse(body)
    
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid symbol' }, { status: 400 })
    }

    const symbol = validation.data.symbol.toUpperCase()

    // Check if already favorited
    const existing = await prisma.favorite.findUnique({
      where: {
        userId_symbol: {
          userId: session.user.id,
          symbol: symbol
        }
      }
    })

    if (existing) {
      return NextResponse.json({ error: 'Already favorited' }, { status: 400 })
    }

    const favorite = await prisma.favorite.create({
      data: {
        symbol: symbol,
        userId: session.user.id,
      }
    })

    return NextResponse.json({ favorite })
  } catch (error) {
    console.error('Create favorite error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}