import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import { z } from 'zod'

const createWatchlistSchema = z.object({
  name: z.string().min(1).max(50),
})

const addItemSchema = z.object({
  symbol: z.string().min(1).max(10),
  note: z.string().optional(),
})

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const watchlists = await prisma.watchlist.findMany({
      where: { userId: session.user.id },
      include: {
        items: {
          orderBy: { createdAt: 'desc' }
        }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ watchlists })
  } catch (error) {
    console.error('Get watchlists error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const validation = createWatchlistSchema.safeParse(body)
    
    if (!validation.success) {
      return NextResponse.json({ error: 'Invalid data' }, { status: 400 })
    }

    const watchlist = await prisma.watchlist.create({
      data: {
        name: validation.data.name,
        userId: session.user.id,
      },
      include: {
        items: true
      }
    })

    return NextResponse.json({ watchlist })
  } catch (error) {
    console.error('Create watchlist error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}