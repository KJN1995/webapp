import { Metadata } from 'next'
import QuoteCard from '@/components/QuoteCard'
import Chart from '@/components/Chart'
import FundamentalsTabs from '@/components/FundamentalsTabs'
import NewsFeed from '@/components/NewsFeed'

interface Props {
  params: Promise<{ symbol: string }>
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { symbol } = await params
  const symbolUpper = symbol.toUpperCase()
  
  return {
    title: `${symbolUpper} Stock Analysis | Stock Analysis Tool`,
    description: `Comprehensive analysis of ${symbolUpper} stock including fundamentals, technical analysis, news, and AI insights.`,
  }
}

export default async function SymbolPage({ params }: Props) {
  const { symbol } = await params
  const symbolUpper = symbol.toUpperCase()

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{symbolUpper} Stock Analysis</h1>
          <p className="text-gray-600">Comprehensive financial analysis and market insights</p>
        </div>

        {/* Quote Card */}
        <div className="mb-8">
          <QuoteCard symbol={symbolUpper} />
        </div>

        {/* Chart */}
        <div className="mb-8 bg-white rounded-lg shadow-md p-6">
          <h2 className="text-xl font-semibold mb-4">Price Chart</h2>
          <Chart symbol={symbolUpper} />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Fundamentals - takes 2 columns */}
          <div className="lg:col-span-2">
            <FundamentalsTabs symbol={symbolUpper} />
          </div>

          {/* News - takes 1 column */}
          <div className="lg:col-span-1">
            <NewsFeed symbol={symbolUpper} />
          </div>
        </div>
      </div>
    </div>
  )
}