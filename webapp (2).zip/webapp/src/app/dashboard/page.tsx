import { redirect } from 'next/navigation'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/db'
import TickerSearch from '@/components/TickerSearch'
import WatchlistWidget from '@/components/WatchlistWidget'
import FavoritesWidget from '@/components/FavoritesWidget'
import HistoryWidget from '@/components/HistoryWidget'

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  
  if (!session) {
    redirect('/auth/signin')
  }

  // Fetch user data
  const [watchlists, favorites, recentHistory] = await Promise.all([
    prisma.watchlist.findMany({
      where: { userId: session.user.id },
      include: { items: true },
      take: 3
    }),
    prisma.favorite.findMany({
      where: { userId: session.user.id },
      take: 10,
      orderBy: { createdAt: 'desc' }
    }),
    prisma.history.findMany({
      where: { userId: session.user.id },
      take: 10,
      orderBy: { viewedAt: 'desc' },
      distinct: ['symbol']
    })
  ])

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Welcome back, {session.user?.name || session.user?.email}
          </h1>
          <p className="text-gray-600">Your personalized stock analysis dashboard</p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="max-w-md">
            <TickerSearch 
              onSelect={(symbol) => redirect(`/symbol/${symbol}`)} 
              placeholder="Search stocks..."
            />
          </div>
        </div>

        {/* Dashboard Widgets */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Watchlists */}
          <div className="lg:col-span-1">
            <WatchlistWidget watchlists={watchlists} />
          </div>

          {/* Favorites */}
          <div className="lg:col-span-1">
            <FavoritesWidget favorites={favorites} />
          </div>

          {/* Recent History */}
          <div className="lg:col-span-1">
            <HistoryWidget history={recentHistory} />
          </div>
        </div>
      </div>
    </div>
  )
}